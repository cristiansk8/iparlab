
<?php
/*
	Campos slider
	- $slider_home (field_repeater)

*/
	$slider_home = get_field('slider_home');
	if($slider_home):
	?>

	<section id="homeSlider">
		<div class="slider-wrapper slider">
			<?php

			while(have_rows('slider')): the_row();
				$imagen = get_sub_field('imagen');

			?>

				<div class="slider--item">
					<img src="<?php echo $imagen; ?>">

				</div>

			<?php endwhile; ?>
		</div>
	</section>

	<?php
	endif;
